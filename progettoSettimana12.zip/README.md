Una SPA con Angular su un catalogo film e sezione login

1) npm i
2) npm install @auth0/angular-jwt
3) npm run full stack
4) registrarsi ed accedere
